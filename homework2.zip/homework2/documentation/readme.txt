to run trap.f90:

gfortran trap.f90 -o myprog
./myprog

then follow instructions on screen

to run ones.f90:
gfortran ones.f90 -o myprog
./myprog