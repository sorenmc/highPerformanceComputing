On grape:

mpif90  filename.f90  -o filename
qsub filename


I also did the files in c:

mpicc  filename.c -o filename
qsub filename